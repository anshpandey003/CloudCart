package com.utkarsh.codelink;

public class TransIdHelper {
    String TransID;
    public TransIdHelper(String TransID){
        this.TransID = TransID;
    }

    public String getTransID() {
        return TransID;
    }

    public void setTransID(String transID) {
        TransID = transID;
    }

    public TransIdHelper(){

    }
}
