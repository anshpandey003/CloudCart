package com.utkarsh.codelink;

public class CreditsHelperClass {
    String Credits;
    public CreditsHelperClass(String Credits){
        this.Credits = Credits;
    }

    public String getCredits() {
        return Credits;
    }

    public void setCredits(String credits) {
        Credits = credits;
    }

    public CreditsHelperClass(){

    }
}
