//package com.example.codelink;
//
//public class Utils {
//    public static final  String EMAIL = "teamcloudcart@gmail.com";
//    public static final String PASSWORD = "Utkarsh@1405";
//}
